# Animations With Lottie
An Android application that makes use of Lottie to load animations. 

# Lottie Library 
airbnb/lottie-android

# Lottie Animation Files 
https://lottiefiles.com/
